const CACHE="iran-lego-living-book-v1";
const CORE=["./","index.html","styles.css","app.js","config.js","data/timing-data.js","data/camera-data.js",
"assets/icons/icon-192.png","assets/icons/icon-512.png","assets/pages/page-01.webp"];
self.addEventListener("install",e=>e.waitUntil(caches.open(CACHE).then(c=>c.addAll(CORE))));
self.addEventListener("activate",e=>e.waitUntil(caches.keys().then(keys=>Promise.all(keys.filter(k=>k!==CACHE).map(k=>caches.delete(k))))));
self.addEventListener("fetch",e=>e.respondWith(caches.match(e.request).then(r=>r||fetch(e.request))));
