I RAN, LEGO! - THE LIVING STORYBOOK v1
======================================

START IT
--------
Windows:
1. Unzip the package.
2. Double-click START_WINDOWS.bat.
3. Your browser opens automatically.

Mac / Linux:
1. Unzip the package.
2. Double-click START_MAC_LINUX.command, or run: python3 start_local.py

The browser experience contains:
- Premium public landing page
- 66-second free interactive preview
- Full 6:39 living storybook in prototype-unlock mode
- Authored camera moves from the v04 camera map
- Word-level lyrics and bouncing red-button marker
- Chapter navigation
- Readable mobile layout
- Pause-and-explore page mode
- Digital / hard-copy / complete edition purchase flow
- PWA files for installable deployment

PAYMENT SETUP
-------------
The prototype deliberately does not pretend to take real money.

Open config.js and paste hosted checkout links into:
- products.digital.checkoutUrl
- products.print.checkoutUrl
- products.complete.checkoutUrl

For production, the checkout success page should create a real server-side customer
entitlement. The localStorage unlock included here is ONLY for previewing the build.

SIMPLE PRODUCTION STACK
-----------------------
- Front end: this package
- Checkout: Stripe hosted Checkout
- Login: email magic link
- Entitlement: one database row per buyer/product
- Book assets: private bucket or signed URLs
- Hard copy: print-on-demand checkout/fulfilment
- Hosting: your existing web host, Vercel, Cloudflare Pages, or Netlify

IMPORTANT
---------
Do not place the original high-resolution PDF in the public web folder.
The page images in this prototype are display assets. Production can swap them for
signed private assets without changing the interface.

Main editable files:
- config.js       prices, product links and contact details
- styles.css      visual design
- app.js          player and access behaviour
- data/*.js       timing and camera information
