window.IRAN_CONFIG = {
  demoMode: true,
  previewSeconds: 66,
  currency: "AUD",
  products: {
    digital: {
      label: "Digital Living Book",
      priceLabel: "Set price",
      checkoutUrl: ""
    },
    print: {
      label: "Hard-Copy Book",
      priceLabel: "Set price",
      checkoutUrl: ""
    },
    complete: {
      label: "Complete Edition",
      priceLabel: "Set price",
      checkoutUrl: ""
    }
  },
  supportEmail: "hello@blkck2.com",
  brandUrl: "https://blkck2.com"
};
