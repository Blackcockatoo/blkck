from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
import webbrowser, threading, os
os.chdir(os.path.dirname(os.path.abspath(__file__)))
url="http://127.0.0.1:8080"
threading.Timer(0.8, lambda:webbrowser.open(url)).start()
print("Opening I RAN, LEGO! at", url)
ThreadingHTTPServer(("127.0.0.1",8080),SimpleHTTPRequestHandler).serve_forever()
