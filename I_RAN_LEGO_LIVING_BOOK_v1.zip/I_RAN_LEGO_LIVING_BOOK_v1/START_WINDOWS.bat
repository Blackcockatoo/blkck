@echo off
python start_local.py
pause
